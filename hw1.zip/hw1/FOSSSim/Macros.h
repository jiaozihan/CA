#ifndef __MACROS_H__
#define __MACROS_H__

#define IGNORE_UNUSED(x) ((void)(x))

#endif /* end of include guard: __MACROS_H__ */
