#include "SceneStepper.h"

SceneStepper::~SceneStepper()
{}
